// src/main.cpp
#include <SFML/Graphics.hpp>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include <thread>
#include <iostream>
#include <stack>
#include <queue>
#include <cmath>

using namespace std::literals;

enum class AlgoId {
    Bubble, Selection, Insertion, Merge, Quick, Heap,
    Cycle, Counting, Radix, Bucket, Tim
};

const std::vector<std::string> algoNames = {
    "Bubble Sort", "Selection Sort", "Insertion Sort", "Merge Sort",
    "Quick Sort", "Heap Sort", "Cycle Sort", "Counting Sort",
    "Radix Sort", "Bucket Sort", "Timsort"
};

const std::vector<float> speedOptions = {0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f};

// ---------------- Utility ----------------
void sleep_ms(int ms) {
    std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}
void reshuffle(std::vector<int>& a) {
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(a.begin(), a.end(), g);
}

// ---------------- Sort engine ----------------
// Each algorithm has its own internal state so we can call step() repeatedly.
// step() returns true if a visual change happened (so we can delay), and sets
// highlight indices for rendering.

struct SortEngine {
    std::vector<int> a;
    std::vector<int> aux; // for merge/counting etc
    AlgoId algo;

    // highlights
    int hi1 = -1, hi2 = -1;

    // common state variables used per algorithm:
    int i = 0, j = 0;         // generic counters
    int len = 0, width = 1;   // for merge iterative
    std::stack<std::pair<int,int>> q; // for quicksort ranges
    // quicksort partition state:
    int ql=0, qr=0, qpivot=-1, qi=-1, qj=-1; bool qPartitioning=false;
    // heap state:
    int heap_n = 0; bool heap_build = true; int heap_idx = 0; // sift index
    // cycle sort:
    int cycle_start = 0, cycle_pos = 0; bool cycle_busy=false;
    // counting sort:
    int count_max = 0; int cnt_idx = 0; bool have_counts=false; std::vector<int> counts;
    int write_pos = 0;
    // radix:
    int radix_digit = 0; bool radix_busy=false; std::vector<std::vector<int>> buckets;
    // bucket:
    std::vector<std::vector<int>> bucket_list; int bucket_phase=0; int bucket_i=0, bucket_j=0;
    // timsort (simplified as run-detection + merges)
    std::vector<std::pair<int,int>> runs; int run_idx=0; bool tim_busy=false;

    bool done = false;

    SortEngine() = default;
    SortEngine(AlgoId id, int n=50) { init(id,n); }

    void init(AlgoId id, int n) {
        algo = id;
        a.resize(n);
        for (int k=0;k<n;++k) a[k]=k+1;
        reshuffle(a);
        aux.assign(n,0);
        reset_state();
    }

    void reset_state() {
        hi1 = hi2 = -1;
        i = j = 0;
        len = (int)a.size();
        width = 1;
        while(!q.empty()) q.pop();
        ql=qr=qpivot=qi=qj=0; qPartitioning=false;
        heap_n = (int)a.size(); heap_build=true; heap_idx = heap_n/2 - 1;
        cycle_start = cycle_pos = 0; cycle_busy=false;
        count_max = 0; cnt_idx=0; have_counts=false; counts.clear(); write_pos=0;
        radix_digit=0; radix_busy=false; buckets.clear();
        bucket_list.clear(); bucket_phase=0; bucket_i=bucket_j=0;
        runs.clear(); run_idx=0; tim_busy=false;
        done = false;
    }

    // return true if step produced a visual change (so caller can sleep)
    bool step() {
        if (done) return false;
        hi1 = hi2 = -1;

        switch(algo) {
            case AlgoId::Bubble:
                return step_bubble();
            case AlgoId::Selection:
                return step_selection();
            case AlgoId::Insertion:
                return step_insertion();
            case AlgoId::Merge:
                return step_merge_iter();
            case AlgoId::Quick:
                return step_quick();
            case AlgoId::Heap:
                return step_heap();
            case AlgoId::Cycle:
                return step_cycle();
            case AlgoId::Counting:
                return step_counting();
            case AlgoId::Radix:
                return step_radix();
            case AlgoId::Bucket:
                return step_bucket();
            case AlgoId::Tim:
                return step_timsort_simple();
        }
        return false;
    }

    // ---------- Bubble ----------
    bool step_bubble() {
        if (i < len) {
            if (j < len - i - 1) {
                hi1 = j; hi2 = j+1;
                if (a[j] > a[j+1]) std::swap(a[j], a[j+1]);
                ++j;
                return true;
            } else {
                j = 0; ++i;
                return true;
            }
        }
        done = true; return false;
    }

    // ---------- Selection ----------
    bool step_selection() {
        if (i >= len) { done = true; return false; }
        // We'll perform one selection per step (scan to find min then swap)
        int minIdx = i;
        hi1 = i; hi2 = i;
        for (int k=i+1;k<len;++k) {
            hi1 = minIdx; hi2 = k;
            if (a[k] < a[minIdx]) minIdx = k;
        }
        if (minIdx != i) std::swap(a[minIdx], a[i]);
        ++i;
        return true;
    }

    // ---------- Insertion ----------
    bool step_insertion() {
        if (i >= len) { done = true; return false; }
        int key = a[i];
        int k = i-1;
        while (k >= 0 && a[k] > key) {
            hi1 = k; hi2 = k+1;
            a[k+1] = a[k];
            --k;
        }
        a[k+1] = key;
        ++i;
        return true;
    }

    // ---------- Merge (iterative bottom-up) ----------
    bool step_merge_iter() {
        // We'll perform merging of one pair-of-runs per step.
        if (width >= len) { done = true; return false; }

        int left = i; // reuse i as left index pointer, j as right start
        // initialize at first call
        if (i==0 && j==0) {
            left = 0;
            j = 0; // j used as flag to indicate we are at start
        } else left = i;

        // find next left where to merge
        if (left >= len) {
            width *= 2;
            i = 0;
            j = 0;
            return true;
        }

        int mid = std::min(left + width, len);
        int right = std::min(left + 2*width, len);
        // merge [left, mid) and [mid, right)
        int p = left, qidx = mid, t = left;
        while (p < mid && qidx < right) {
            hi1 = p; hi2 = qidx;
            if (a[p] <= a[qidx]) aux[t++] = a[p++]; else aux[t++] = a[qidx++];
        }
        while (p < mid) { aux[t++] = a[p++]; }
        while (qidx < right) { aux[t++] = a[qidx++]; }
        for (int k=left;k<right;++k) a[k] = aux[k];
        // advance left for next merge
        i = right;
        if (i >= len) { // next call will double width
            width *= 2;
            i = 0;
        }
        return true;
    }

    // ---------- Quick (iterative with explicit stack and stepwise partition) ----------
    bool start_partition(int L, int R) {
        ql = L; qr = R;
        qpivot = a[R];
        qi = L; qj = R-1;
        qPartitioning = true;
        return true;
    }
    bool finish_partition_and_push(int storeIndex) {
        // place pivot at storeIndex by swapping a[storeIndex] and a[qr]
        std::swap(a[storeIndex], a[qr]);
        // push subranges
        if (storeIndex+1 < qr) q.push({storeIndex+1, qr});
        if (ql < storeIndex-1) q.push({ql, storeIndex-1});
        qPartitioning = false;
        return true;
    }
    bool step_quick() {
        if (q.empty() && !qPartitioning) {
            // initialize with full range
            q.push({0, len-1});
        }
        if (!qPartitioning) {
            if (q.empty()) { done = true; return false; }
            auto seg = q.top(); q.pop();
            start_partition(seg.first, seg.second);
            return true;
        } else {
            // partitioning underway
            if (qi <= qj) {
                hi1 = qi; hi2 = qj;
                if (a[qi] <= qpivot) { ++qi; return true; }
                if (a[qj] > qpivot) { --qj; return true; }
                std::swap(a[qi], a[qj]);
                ++qi; --qj;
                return true;
            } else {
                // swap with pivot position (qi)
                int storeIndex = qi;
                std::swap(a[storeIndex], a[qr]);
                // push ranges
                if (storeIndex+1 <= qr) {
                    if (storeIndex+1 < qr) q.push({storeIndex+1, qr});
                }
                if (ql <= storeIndex-1) {
                    if (ql < storeIndex-1) q.push({ql, storeIndex-1});
                }
                qPartitioning = false;
                return true;
            }
        }
    }

    // ---------- Heap sort ----------
    // We'll do build-heap step-wise and then extract elements step-wise.
    // Helper sift-down for index idx up to heap_size-1
    bool sift_down(int heap_size, int idx) {
        int largest = idx;
        int l = 2*idx + 1, r = 2*idx + 2;
        if (l < heap_size && a[l] > a[largest]) largest = l;
        if (r < heap_size && a[r] > a[largest]) largest = r;
        if (largest != idx) {
            hi1 = idx; hi2 = largest;
            std::swap(a[idx], a[largest]);
            // continue sifting on largest
            return sift_down(heap_size, largest);
        }
        return false;
    }
    bool step_heap() {
        if (heap_build) {
            if (heap_idx >= 0) {
                // sift this node
                sift_down(heap_n, heap_idx);
                --heap_idx;
                return true;
            } else {
                heap_build = false;
                return true;
            }
        } else {
            if (heap_n > 1) {
                std::swap(a[0], a[heap_n-1]);
                --heap_n;
                sift_down(heap_n, 0);
                return true;
            } else {
                done = true; return false;
            }
        }
    }

    // ---------- Cycle sort ----------
    bool step_cycle() {
        if (cycle_start >= len-1) { done = true; return false; }
        if (!cycle_busy) {
            cycle_pos = cycle_start;
            int item = a[cycle_start];
            int pos = cycle_start;
            for (int i=cycle_start+1;i<len;++i) {
                hi1 = pos; hi2 = i;
                if (a[i] < item) ++pos;
            }
            if (pos == cycle_start) {
                ++cycle_start;
                return true;
            }
            // skip duplicate elements
            while (item == a[pos]) ++pos;
            std::swap(item, a[pos]);
            cycle_busy = true;
            cycle_pos = pos;
            j = item; // reuse j to store item value temporarily
            return true;
        } else {
            // place item into correct position, rotate until back
            int item = j;
            int pos = cycle_start;
            for (int i=cycle_start+1;i<len;++i) {
                hi1 = pos; hi2 = i;
                if (a[i] < item) ++pos;
            }
            while (item == a[pos]) ++pos;
            std::swap(item, a[pos]);
            j = item;
            if (pos == cycle_start) {
                cycle_busy = false;
                ++cycle_start;
            }
            return true;
        }
    }

    // ---------- Counting sort ----------
    bool step_counting() {
        if (!have_counts) {
            // build count array
            count_max = 0;
            for (int v : a) if (v > count_max) count_max = v;
            counts.assign(count_max+1, 0);
            for (int v : a) counts[v]++;
            // convert counts to running positions
            int sum=0;
            for (int k=0;k<=count_max;++k) {
                int c = counts[k];
                counts[k] = sum;
                sum += c;
            }
            aux.assign(len,0);
            cnt_idx = 0;
            have_counts = true;
            return true;
        } else if (cnt_idx < len) {
            int v = a[cnt_idx];
            int pos = counts[v]++;
            aux[pos] = v;
            ++cnt_idx;
            return true;
        } else {
            // copy back one element per step
            if (write_pos < len) {
                a[write_pos] = aux[write_pos];
                ++write_pos;
                return true;
            } else {
                done = true; return false;
            }
        }
    }

    // ---------- Radix (LSD base 10) ----------
    bool step_radix() {
        if (!radix_busy) {
            int maxv = 0;
            for (int v : a) if (v > maxv) maxv = v;
            int base = 1;
            int d = 0;
            while (maxv / base > 0) { ++d; base *= 10; }
            radix_digit = 0;
            buckets.assign(10, {});
            radix_busy = true;
            return true;
        }
        // distribute by digit for current digit
        if (radix_digit < 10*1000) {} // unused
        // We'll process one pass completely per step (makes sense visually)
        // find max digits
        int maxv = 0;
        for (int v : a) if (v > maxv) maxv = v;
        int exp = 1;
        for (int k=0;k<radix_digit;++k) exp*=10;
        bool any = false;
        for (int v : a) {
            int d = (v/exp)%10;
            buckets[d].push_back(v);
            any = true;
        }
        // collect into aux
        int idx = 0;
        for (int b=0;b<10;++b) {
            for (int val : buckets[b]) {
                aux[idx++] = val;
            }
            buckets[b].clear();
        }
        // copy back
        for (int k=0;k<len;++k) a[k]=aux[k];
        ++radix_digit;
        // stop if no more digits
        int maxdigits=0; int tmp=0; for (int v:a) if (v>tmp) tmp=v;
        while (tmp>0) { tmp/=10; ++maxdigits; }
        if (radix_digit >= maxdigits) { done = true; radix_busy=false; return true; }
        return true;
    }

    // ---------- Bucket sort ----------
    bool step_bucket() {
        if (bucket_phase==0) {
            // distribute into buckets
            int nBuckets = std::max(1, (int)std::sqrt(len));
            bucket_list.assign(nBuckets, {});
            int maxv = 0; for (int v:a) if (v>maxv) maxv=v;
            for (int v : a) {
                int idx = (int)((v * 1.0 / (maxv+1)) * nBuckets);
                if (idx < 0) idx = 0;
                if (idx >= nBuckets) idx = nBuckets-1;
                bucket_list[idx].push_back(v);
            }
            bucket_phase = 1;
            bucket_i = 0;
            return true;
        } else if (bucket_phase==1) {
            // sort one bucket per step (using insertion)
            if (bucket_i >= (int)bucket_list.size()) {
                bucket_phase = 2; bucket_i=0; bucket_j=0; return true;
            }
            auto &bk = bucket_list[bucket_i];
            // perform one insertion sort full on that bucket
            for (int x=1;x<(int)bk.size();++x) {
                int key = bk[x]; int y=x-1;
                while (y>=0 && bk[y] > key) { bk[y+1] = bk[y]; --y;}
                bk[y+1] = key;
            }
            ++bucket_i;
            return true;
        } else if (bucket_phase==2) {
            // write back buckets one element at a time
            int pos = 0;
            for (auto &bk : bucket_list) pos += bk.size();
            int kpos = 0;
            for (auto &bk : bucket_list) {
                for (int v: bk) { a[kpos++] = v; return true; }
            }
            // if we reached here, one step per element wasn't done; but for simplicity copy all
            int idx=0;
            for (auto &bk : bucket_list) for (int v:bk) a[idx++]=v;
            done = true; return true;
        }
        return false;
    }

    // ---------- Timsort (very simplified): detect runs and merge progressively ----------
    bool step_timsort_simple() {
        if (!tim_busy) {
            // detect runs
            runs.clear();
            int n = len;
            int start = 0;
            while (start < n) {
                int end = start+1;
                if (end == n) { runs.push_back({start, end}); break; }
                if (a[end] >= a[end-1]) {
                    while (end < n && a[end] >= a[end-1]) ++end;
                } else {
                    while (end < n && a[end] < a[end-1]) ++end;
                    std::reverse(a.begin()+start, a.begin()+end);
                }
                runs.push_back({start, end});
                start = end;
            }
            tim_busy = true;
            run_idx = 0;
            return true;
        } else {
            // merge adjacent runs progressively (one merge per step)
            if (runs.size() <= 1) { done = true; tim_busy=false; return true; }
            // merge first two runs
            auto r1 = runs[0]; auto r2 = runs[1];
            int l = r1.first, m = r1.second, r = r2.second;
            // perform merge into aux
            int p = l, q = m, t = l;
            while (p < m && q < r) {
                hi1 = p; hi2 = q;
                if (a[p] <= a[q]) aux[t++] = a[p++]; else aux[t++] = a[q++];
            }
            while (p < m) aux[t++] = a[p++];
            while (q < r) aux[t++] = a[q++];
            for (int k=l;k<r;++k) a[k] = aux[k];
            // replace runs[0] and runs[1] with merged
            runs.erase(runs.begin());
            runs[0].first = l; runs[0].second = r;
            return true;
        }
    }
};

// ---------------- Main Program ----------------
int main() {
    const int winW = 1200, winH = 700;
    const int leftW = 320;
    const int N = 120; // initial number of bars (adjustable)
    sf::RenderWindow window(sf::VideoMode(winW, winH), "Algorithm Visualizer");
    window.setFramerateLimit(60);

    // load font
    sf::Font font;
    if (!font.loadFromFile("../assets/arial.ttf")) {
        std::cerr<<"Failed to load font ../assets/arial.ttf\n";
        // continue without text (but user should add font)
    }

    // create engine per algorithm for easy switching/persistence
    std::vector<SortEngine> engines;
    engines.resize(algoNames.size());
    for (int k=0;k<algoNames.size();++k) engines[k].init((AlgoId)k, N);

    int currentAlgoIndex = 0;
    float speed = 1.0f;
    bool running = false;

    // UI element rectangles (for mouse clicks)
    // Algorithms list area: vertical buttons
    std::vector<sf::FloatRect> algoRects;
    std::vector<sf::FloatRect> speedRects;
    sf::FloatRect shuffleRect, playRect;

    // prepare left panel static layout
    int y0 = 60;
    int lineH = 26;
    algoRects.resize(algoNames.size());
    for (int k=0;k<algoNames.size();++k) {
        algoRects[k] = sf::FloatRect(10, y0 + k*lineH, leftW - 20, lineH-4);
    }
    int speedStartY = y0 + algoNames.size()*lineH + 30;
    speedRects.resize(speedOptions.size());
    for (int k=0;k<speedOptions.size();++k) {
        speedRects[k] = sf::FloatRect(10, speedStartY + k*lineH, leftW - 20, lineH-4);
    }
    shuffleRect = sf::FloatRect(10, winH - 100, leftW - 20, 28);
    playRect = sf::FloatRect(10, winH - 60, leftW - 20, 28);

    // main loop
    while (window.isOpen()) {
        // event handling
        sf::Event ev;
        while (window.pollEvent(ev)) {
            if (ev.type == sf::Event::Closed) window.close();
            else if (ev.type == sf::Event::MouseButtonPressed && ev.mouseButton.button == sf::Mouse::Left) {
                sf::Vector2f mp(ev.mouseButton.x, ev.mouseButton.y);
                // check algo clicks
                for (int k=0;k<algoRects.size();++k) {
                    if (algoRects[k].contains(mp)) {
                        currentAlgoIndex = k;
                        running = false;
                        // reset current engine state to start from scratch on that algorithm
                        engines[k].init((AlgoId)k, N);
                        break;
                    }
                }
                // check speed clicks
                for (int k=0;k<speedRects.size();++k) {
                    if (speedRects[k].contains(mp)) {
                        speed = speedOptions[k];
                        break;
                    }
                }
                if (shuffleRect.contains(mp)) {
                    // reshuffle all engines
                    for (int k=0;k<engines.size();++k) engines[k].init((AlgoId)k, N);
                    running = false;
                }
                if (playRect.contains(mp)) {
                    running = !running;
                }
            } else if (ev.type == sf::Event::KeyPressed) {
                if (ev.key.code == sf::Keyboard::Space) running = !running;
                else if (ev.key.code == sf::Keyboard::Up) speed = std::min(2.0f, speed + 0.25f);
                else if (ev.key.code == sf::Keyboard::Down) speed = std::max(0.25f, speed - 0.25f);
            }
        }

        // Step engine if running (use delay derived from speed)
        if (running) {
            // do one step for current engine
            SortEngine &E = engines[currentAlgoIndex];
            bool steped = E.step();
            // when an algorithm finishes, mark running false
            if (E.done) running = false;
            // sleep based on speed: base 30ms scaled by 1/speed
            int base = 30;
            int wait = std::max(1, (int)(base / speed));
            sleep_ms(wait);
        }

        // drawing
        window.clear(sf::Color(24,24,24));

        // left panel
        sf::RectangleShape left(sf::Vector2f(leftW, winH));
        left.setPosition(0,0);
        left.setFillColor(sf::Color(40,40,45));
        window.draw(left);

        // Title
        if (font.getInfo().family.size()) {
            sf::Text title("Algorithm Visualizer", font, 20);
            title.setPosition(12, 12);
            title.setFillColor(sf::Color::White);
            window.draw(title);
        }

        // draw algorithm list
        for (int k=0;k<algoNames.size();++k) {
            sf::RectangleShape rect(sf::Vector2f(algoRects[k].width, algoRects[k].height));
            rect.setPosition(algoRects[k].left, algoRects[k].top);
            rect.setFillColor(k==currentAlgoIndex ? sf::Color(70,70,80) : sf::Color(55,55,60));
            window.draw(rect);
            if (font.getInfo().family.size()) {
                sf::Text t(algoNames[k], font, 16);
                t.setPosition(algoRects[k].left + 6, algoRects[k].top + 3);
                t.setFillColor(k==currentAlgoIndex ? sf::Color::Yellow : sf::Color::White);
                window.draw(t);
            }
        }

        // draw speed options
        if (font.getInfo().family.size()) {
            sf::Text sTitle("Speed:", font, 16);
            sTitle.setPosition(12, speedStartY - 28);
            sTitle.setFillColor(sf::Color::White);
            window.draw(sTitle);
        }
        for (int k=0;k<speedOptions.size();++k) {
            sf::RectangleShape rect(sf::Vector2f(speedRects[k].width, speedRects[k].height));
            rect.setPosition(speedRects[k].left, speedRects[k].top);
            rect.setFillColor(speed==speedOptions[k]? sf::Color(70,70,80) : sf::Color(55,55,60));
            window.draw(rect);
            if (font.getInfo().family.size()) {
                sf::Text t((std::to_string(speedOptions[k]) + "x"), font, 15);
                t.setPosition(speedRects[k].left + 6, speedRects[k].top + 1);
                t.setFillColor(speed==speedOptions[k] ? sf::Color::Cyan : sf::Color::White);
                window.draw(t);
            }
        }

        // shuffle + play/pause buttons
        {
            sf::RectangleShape r(sf::Vector2f(shuffleRect.width, shuffleRect.height));
            r.setPosition(shuffleRect.left, shuffleRect.top);
            r.setFillColor(sf::Color(80,80,85));
            window.draw(r);
            if (font.getInfo().family.size()) {
                sf::Text t("Shuffle", font, 16);
                t.setPosition(shuffleRect.left + 8, shuffleRect.top + 4);
                t.setFillColor(sf::Color::White);
                window.draw(t);
            }
        }
        {
            sf::RectangleShape r(sf::Vector2f(playRect.width, playRect.height));
            r.setPosition(playRect.left, playRect.top);
            r.setFillColor(running? sf::Color(0,120,0) : sf::Color(80,80,85));
            window.draw(r);
            if (font.getInfo().family.size()) {
                sf::Text t(running? "Pause (Click / Space)" : "Play (Click / Space)", font, 16);
                t.setPosition(playRect.left + 8, playRect.top + 4);
                t.setFillColor(sf::Color::White);
                window.draw(t);
            }
        }

        // status & speed display
        if (font.getInfo().family.size()) {
            sf::Text st(("Current: " + algoNames[currentAlgoIndex]), font, 14);
            st.setPosition(12, winH - 140);
            st.setFillColor(sf::Color::Yellow);
            window.draw(st);

            sf::Text sp(("Speed: " + std::to_string(speed) + "x"), font, 14);
            sp.setPosition(12, winH - 118);
            sp.setFillColor(sf::Color::Cyan);
            window.draw(sp);
        }

        // Right panel: draw bars for current algorithm engine
        SortEngine &E = engines[currentAlgoIndex];
        const auto &arr = E.a;
        int n = (int)arr.size();
        float rightX = (float)leftW;
        float rightW = (float)(winW - leftW);
        float barW = rightW / n;

        for (int idx=0; idx<n; ++idx) {
            float h = (arr[idx] / (float)n) * (winH - 40);
            sf::RectangleShape bar(sf::Vector2f(std::max(1.0f, barW-1.0f), h));
            bar.setPosition(rightX + idx*barW, winH - h);
            if (idx == E.hi1 || idx == E.hi2) bar.setFillColor(sf::Color::Red);
            else if (E.done) bar.setFillColor(sf::Color(80,200,120));
            else bar.setFillColor(sf::Color(60,200,220));
            bar.setOutlineColor(sf::Color(20,20,20));
            bar.setOutlineThickness(-1.f);
            window.draw(bar);
        }

        window.display();
    }

    return 0;
}
